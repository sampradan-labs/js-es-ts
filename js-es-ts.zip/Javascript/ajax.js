this.GetPosts = function(){
//Create XmlHttpRequest Object
//HTTP Verbs
/*
    GET: To get data from server ~ SELECT QUERY
    POST: To create new response on server ~ INSERT QUERY
    PUT: To update an existing response on server ~ UPDATE QUERY
    DELETE: To delete an existing response from the server ~ DELETE
*/
var xhr = new XMLHttpRequest();
//Send this request over HTTP (internet) to the server
xhr.open('GET','https://jsonplaceholder.typicode.com/posts/1');
xhr.send();
xhr.onload = function(){
    if (xhr.status != 200) {
        alert('Error ', xhr.status, xhr.statusText)
    } else {
        addToHtml(xhr.response);
    }
 }
}

var addToHtml = function(response){
   var luserId = document.getElementById("lblUserId");
   var lid = document.getElementById("lblId");
   var lbody = document.getElementById("lblBody");

   var resultObj = JSON.parse(response);
   luserId.innerText = resultObj.userId;
   lid.innerText = resultObj.id;
   lbody.innerText = resultObj.body;
}

this.InsertPost = function(){
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'https://jsonplaceholder.typicode.com/posts/');
    xhr.setRequestHeader('Content-Type','application/json');
    var jsonParam = {
        id:999,
        userId: 999,
        title: "New Title",
        body: "Lorem Ipsum"
    };
    xhr.send(JSON.stringify(jsonParam));
    xhr.onload = function(){
        if (xhr.status == 201) {
            console.log(xhr.response);
        } else {
            alert('Error', xhr.status, xhr.statusText);
        }
    }

}

this.LocalServerGet = function(){
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://localhost:5001/posts/');    
    xhr.send();
    xhr.onload = function(){
        if (xhr.status == 200) {
            console.log(xhr.response);
        } else {
            alert('Error', xhr.status, xhr.statusText);
        }
    }

}




