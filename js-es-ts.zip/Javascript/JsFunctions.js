//Technique 1
//function <fName>(){}
myDogYears(20);
function myDogYears(age){
    console.log("My Dog Age is: " + age/7);
}

//Technique 2
//var v = function(){}

var myDogYearsV2 = function(age){
    console.log("My Dog Age V2 is: " + age/7); 
}
myDogYearsV2(20);

//Technique 3 - Anonymous functions
//function(){}
//( <function-implementation> )()
(function(age){
    console.log("My Dog Age V3 is: " + age/7);
})(20);