﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PostsServerApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PostsController : ControllerBase
    {
        [EnableCors("AllowAll")]
        [HttpGet("/posts")]
        public List<Posts> Get()
        {

            List<Posts> allPosts = new List<Posts>();
            allPosts.Add(new Posts() { userId = 1, id = 1, title = "Heading 1", body = "lorem ipsum" });
            allPosts.Add(new Posts() { userId = 2, id = 1, title = "Heading 2", body = "zorem gypsum" });
            allPosts.Add(new Posts() { userId = 3, id = 1, title = "Heading 3", body = "corem lumpsum" });
            return allPosts;

        }

        public int breadth { get; set; }
        public int height { get; set; }

        [HttpGet("/lambdas")]
        public int WithLambdas()
        {
            this.breadth = 11;
            this.height = 11;
            Func<int> area = () => this.breadth * this.height;
            return area();
        }
    }

    public class Posts
    {
        public int userId { get; set; }
        public int id { get; set; }
        public string title { get; set; }
        public string body { get; set; }
    }
}
