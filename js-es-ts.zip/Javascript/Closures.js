function NormalFun(){
    console.log("Normal Function");
}
NormalFun();

(function(){
    console.log("Anonymous function - self invoking");
})();

//Anonymous + closure to be returned
function parentFun(){
    return function(){ console.log("Nested into normal function");}
}

//Using normal way
var result = parentFun();
result();
//Using currying of functions or closures
parentFun()();
// Internal Intermediate step after parentFun()
// (function(){ 
//             console.log("Nested into normal function");
//         }
// )();


//======== 3 levels of closure =============
//work returns a function
function work(){

    function taskCode(){
        console.log("Coding in progress");
    }

    //A function returning another function
    function taskUpgrade(){
        console.log("Certification in progress");
        return taskCode;
    }

    return taskUpgrade;

}

//Work() RETURNS taskUpgrade Function RETURNS taskCode Function
work()()();

//=========== Returning a hierarchy of functions using closures
function getObject(){
    var result = {
        work: function(taskName, status){
                                            console.log(taskName + 'is in '+status + ' state');
                                         },
        play: function(gameName){
                                    console.log("Playing the game: "+gameName);
                                }
    };

    //result.work('Json coding', 'In-Progress');

    return result;
}

getObject().work('Json coding', 'In-Progress');
getObject().play('Minecraft');

//Returning as function
function getObjectClosure(){
    var result = {
        work: function(taskName, status){
                                            console.log(taskName + 'is in '+status + ' state');
                                         },
        play: function(gameName){
                                    console.log("Playing the game: "+gameName);
                                }
    };

    //result.work('Json coding', 'In-Progress');

    return function(){return result;}
}

getObjectClosure()().work("Complex coding", 'In-Progress');






























