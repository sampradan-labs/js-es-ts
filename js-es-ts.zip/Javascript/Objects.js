var obj = {};   //A javascript object notation OR JSON

var obj2 = {
    k1:100,
    k2:'Tomatoes',
    k3: ['Eena','Meena','Deeka'],
    k4: { sk1: 999.999,
          sk2: [300, 'Groceries'],
          sk3: { ssk1: 'Antiques'}
        }
};

//to access keys in objects, use '.'
//to access array items, use [<pos_index>]
obj2.k1=10000;
console.log(obj2.k1);   //100
console.log(obj2.k3[1]);    //Meena
console.log(obj2.k4.sk1);   //999.999
console.log(obj2.k4.sk2[1]);    //Groceries