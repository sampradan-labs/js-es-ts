(function(){
    this.Movie = function Movie(){

                            //Creating properties in a public scope
                            this.name='';
                            this.cast=[];
                            this.rating=0.0;
                            this.ticketCost = 0.0;
                            var privateProperty = 'I am private';

                            //public functions
                            this.Book = function(){return "Ticket booked for "+ this.name + '. Total cost is INR '+ this.ticketCost};
                            var CanYouAccessMe = function(){
                                        return false;
                                     }
                }           

    this.GetMovieCount = function(collection){
                            return collection.length;
                    };
    this.GetTotalEarnings = function(collection){
    var totalCost = 0.0;
    for (let index = 0; index < collection.length; index++) {
        totalCost += collection[index].ticketCost;                                    
    }
    return totalCost;
    };
})();

(function(){

    this.Output = "More than one closures are accessible!!";
})();

this.Utils = {
    addOnSnacks: function(){
                            console.log('Added evening snacks worth INR 500');
                            },
    getCouponCode: function(){
        return 'MOV30OFF';
    }                   
};