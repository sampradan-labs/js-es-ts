interface IDbOps{
    select():any[];
    insert:(...values:any[])=>void
    update:(old,newval)=>boolean;
    delete:(value:any)=>void
}

class SqlServer implements IDbOps{
    select():any[]{
        return ['Eena','Meena','Deeka'];
    }

    insert(...values:any[]):void{
        console.log(`Values inserted in DB: ${values}`);        
    }

    update(old: any, newval: any):boolean{
        console.log(`Updated value to ${newval}`);
        return true;
    }

    delete(value: any): void{
        console.log('Delete successful');
    }
}

//Create instance using mantra base = new derived()
let instance:IDbOps = new SqlServer();
console.log(instance.select());
instance.insert('Neha','Rita','Sushma');
console.log(instance.update('Rita','Neema'));
instance.delete('Neema');