//Promise is a used for a function that takes some time to execute and 
//it must execute asynchronously 
var myPromise = new Promise(function (myResolve, myReject) {
    setTimeout(function () {
        myResolve("Yes, will get marriend to my bf");
    }, 3000);
});
myPromise.then(function (value) {
    console.log('Booking to go to Bahamas');
}, (function (err) { console.log('Will go the bar...'); }));

