function SelfDriving(constructorFn:Function) {
    //constructorFn is called when the object of car is created
    console.log('--- Inside SelfDriving Decorator --');
    constructorFn.prototype.selfDrivable = true;
    constructorFn.prototype.gpsSystem = 'Google';
}

@SelfDriving
class Car {
    private _make: string;
    constructor(make: string) {
        console.log('-- this constructor invoked --');
        this._make = make;
    }
}

//--instantiate
let maruti:Car = new Car("Maruti");
console.log(maruti);
console.log(`selfdriving: ${maruti['selfDrivable']} 
            | GPS used: ${maruti['gpsSystem']}`);

/// HTML using Typescript
//convert a class to a html tag
function HtmlComponent(constructorFn:Function){
    constructorFn.prototype.tag = '<user></user>'
    //document.appendChild(constructorFn.prototype.tag);
}

@HtmlComponent
class User{
    constructor(){
        console.log('User instantiated');
    }
}

//instantiate
let user = new User();
console.log(`${user['tag']}`);