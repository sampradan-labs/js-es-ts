var SqlServer = /** @class */ (function () {
    function SqlServer() {
    }
    SqlServer.prototype.select = function () {
        return ['Eena', 'Meena', 'Deeka'];
    };
    SqlServer.prototype.insert = function () {
        var values = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            values[_i] = arguments[_i];
        }
        console.log("Values inserted in DB: ".concat(values));
    };
    SqlServer.prototype.update = function (old, newval) {
        console.log("Updated value to ".concat(newval));
        return true;
    };
    SqlServer.prototype["delete"] = function (value) {
        console.log('Delete successful');
    };
    return SqlServer;
}());
//Create instance
var instance = new SqlServer();
console.log(instance.select());
instance.insert('Neha', 'Rita', 'Sushma');
console.log(instance.update('Rita', 'Neema'));
instance["delete"]('Neema');
