//Promise is a used for a function that takes some time to execute and 
//it must execute asynchronously 
const myPromise = new Promise((myResolve, myReject)=>{
                                setTimeout(() => {
                                    myResolve("Yes, will get marriend to my bf");
                                }, 3000);
                    })

myPromise.then((value)=>{
    console.log('Booking to go to Bahamas');
}, ((err)=>{console.log('Will go the bar...')}))

//execute directly with node promises.ts

//new Promise((success,fail)=>{})