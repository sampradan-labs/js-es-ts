System.register([], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var EMP_PREFIX, Person, Employee, Kalyan, Sanjeeb, Superperson, jsEmpObj;
    var __moduleName = context_1 && context_1.id;
    //JS class with overloading
    function jsEmployee() {
        this.Works = function () { return console.log('Works'); };
        this.Works = function (taskName) { return console.log("Works on ".concat(taskName)); };
    }
    return {
        setters: [],
        execute: function () {
            exports_1("EMP_PREFIX", EMP_PREFIX = 'DANSKE-');
            Person = /** @class */ (function () {
                function Person(name, age, pan) {
                    this.Name = name;
                    this.Age = age;
                    this.Pan = pan;
                }
                Person.Lives = function () {
                    console.log("Person Lives for about 90years");
                };
                Person.prototype.GetFamilyMembers = function () {
                    console.log("Has parents, cousins and friends living together");
                };
                Person.prototype.Works = function () {
                    console.log("".concat(this.Name, " Works from home"));
                };
                return Person;
            }());
            Employee = /** @class */ (function (_super) {
                __extends(Employee, _super);
                function Employee(name, age, pan) {
                    return _super.call(this, name, age, pan) || this;
                }
                Employee.prototype.Works = function (taskName, status) {
                    var rest = [];
                    for (var _i = 2; _i < arguments.length; _i++) {
                        rest[_i - 2] = arguments[_i];
                    }
                    console.log("".concat(this.Name, " Works for Danske IT as ").concat(this.Designation, " on the task ").concat(taskName));
                };
                return Employee;
            }(Person));
            //// Create instances
            Kalyan = new Person("Kalyan");
            Kalyan.Works();
            Sanjeeb = new Employee('Sanjeeb', 29, 'AAOBH87721Z');
            Sanjeeb.Designation = "Senior Developer";
            Sanjeeb.Works('coding');
            //Base = new Derived()
            Superperson = new Employee('SuperPerson', 30, 'AGKUD392032Z');
            Superperson.Works();
            jsEmpObj = new jsEmployee();
            jsEmpObj.Works('typescript');
        }
    };
});
