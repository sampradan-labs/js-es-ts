function increment(empName?:string, defValue:number = 1,ctc:number = 1000000) : string
{
    return `${empName} has received an upgraded ctc of INR ${Math.random() * defValue + ctc}`;
}

var execSP = (spName:string, ...params:any[]) => console.log(`Executing ${spName} with params ${params}`);
console.log(increment());
console.log(increment("Anand"));
console.log(increment("Anand",10,2000000));

execSP("spInsertEmployee", 1001,"Anand");
/*sequence of parameters combinetion
optional
default
*/
/*Write a function which has mandatory params, optional params, default params, rest params */
var fn = (defVal?:string, ...r2:string[])=>{
    console.log(`defValue:${defVal}, r2: ${r2}`);
}

fn();
fn("Apples");
fn("Apples", "Oranges");

//===========
enum Language {Typescript=10, CSharp=20, VB=30, Java=40, ES=50, JS=60};
var getLanguage = () => Language.Typescript; 
console.log(getLanguage());

//=========== TUPLES: Arrays that hold values of different datatypes
let mytuple = ["IPhone7",['Gowns', 'Sarees', 'Formals'], 5000];
console.log(mytuple[0])
console.log(mytuple[2]);

//===== UNION
let empId: (string | number | boolean);
empId = 1001;
empId = 'DANSKE-'+11874;
empId = 1;

function unite(val:(string|boolean)):(string | number){
    switch (val) {
        case 'value':
            return 5000;
            break;
    
        default:
            return 'Its as good as it gets';
            break;
    }
}

console.log(unite('value'));
console.log(unite(true));