export class Person{
    constructor(name?:string, age?:number, pan?:string){
        this.Name = name;
        this.Age = age;
        this.Pan = pan;
    }

    public Pan:string;
    public Name:string;
    public Age:number;
    protected TotalAssetsValue:number;
    private secrets:string[];
    static Lives():void{
        console.log(`Person Lives for about 90years`);
    }

    protected GetFamilyMembers(){
        console.log("Has parents, cousins and friends living together");
    }

    public Works():void{
        console.log(`${this.Name} Works from home`);
    }
}