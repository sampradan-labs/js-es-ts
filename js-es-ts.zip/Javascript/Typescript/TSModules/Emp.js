System.register(["./PersonClass"], function (exports_1, context_1) {
    "use strict";
    var __extends = (this && this.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var PersonClass_1, Employee;
    var __moduleName = context_1 && context_1.id;
    //JS class with overloading
    function jsEmployee() {
        this.Works = function () { return console.log('Works'); };
        this.Works = function (taskName) { return console.log("Works on ".concat(taskName)); };
    }
    exports_1("jsEmployee", jsEmployee);
    return {
        setters: [
            function (PersonClass_1_1) {
                PersonClass_1 = PersonClass_1_1;
            }
        ],
        execute: function () {
            Employee = /** @class */ (function (_super) {
                __extends(Employee, _super);
                function Employee(name, age, pan) {
                    return _super.call(this, name, age, pan) || this;
                }
                Employee.prototype.Works = function (taskName, status) {
                    var rest = [];
                    for (var _i = 2; _i < arguments.length; _i++) {
                        rest[_i - 2] = arguments[_i];
                    }
                    console.log("".concat(this.Name, " Works for Danske IT as ").concat(this.Designation, " on the task ").concat(taskName));
                };
                return Employee;
            }(PersonClass_1.Person));
            exports_1("Employee", Employee);
        }
    };
});
//# sourceMappingURL=Emp.js.map