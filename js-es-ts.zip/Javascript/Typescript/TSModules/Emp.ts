//import {<exportObject>} from '<filename-without-extension>'
import { Person } from "./PersonClass";

export class Employee extends Person{
    constructor(name:string, age:number, pan:string){
        super(name, age, pan);
    }

    public Designation:string;
    //overriding the behaviour
    public Works();
    public Works(taskname);
    public Works(taskName?:string, status?:boolean,...rest:string[]): void {
        console.log(`${this.Name} Works for Danske IT as ${this.Designation} on the task ${taskName}`);
    }    

}

//JS class with overloading
export function jsEmployee(){
    this.Works = ()=>console.log('Works');
    this.Works = (taskName)=>console.log(`Works on ${taskName}`);
}