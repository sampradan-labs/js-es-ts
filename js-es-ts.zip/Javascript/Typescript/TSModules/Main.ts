import { Person } from "./PersonClass";
import { Employee } from "./Emp";


//// Create instances
let Kalyan:Person = new Person("Kalyan");
Kalyan.Works();

let Sanjeeb:Employee = new Employee('Sanjeeb', 29, 'AAOBH87721Z');
Sanjeeb.Designation = "Senior Developer"
Sanjeeb.Works('coding');

//Base = new Derived()
let Superperson: Person = new Employee('SuperPerson', 30, 'AGKUD392032Z');
Superperson.Works();
console.log("hello");
document.getElementById('output').innerHTML = `Person Name: ${Superperson.Name}, Person Age: ${Superperson.Age}`


// let jsEmpObj = new jsEmployee();
// jsEmpObj.Works('typescript');