System.register(["./Emp", "./PersonClass"], function (exports_1, context_1) {
    "use strict";
    var Emp_1, PersonClass_1, Kalyan, Sanjeeb, Superperson, jsEmpObj;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [
            function (Emp_1_1) {
                Emp_1 = Emp_1_1;
            },
            function (PersonClass_1_1) {
                PersonClass_1 = PersonClass_1_1;
            }
        ],
        execute: function () {
            //// Create instances
            Kalyan = new PersonClass_1.Person("Kalyan");
            Kalyan.Works();
            Sanjeeb = new Emp_1.Employee('Sanjeeb', 29, 'AAOBH87721Z');
            Sanjeeb.Designation = "Senior Developer";
            Sanjeeb.Works('coding');
            //Base = new Derived()
            Superperson = new Emp_1.Employee('SuperPerson', 30, 'AGKUD392032Z');
            Superperson.Works();
            //document.getElementById('output').innerText = `Person Name: ${Superperson.Name}, Person Age: ${Superperson.Age}`
            jsEmpObj = new Emp_1.jsEmployee();
            jsEmpObj.Works('typescript');
        }
    };
});
//# sourceMappingURL=Main.js.map