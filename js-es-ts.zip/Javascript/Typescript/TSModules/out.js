var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
System.register("PersonClass", [], function (exports_1, context_1) {
    "use strict";
    var Person;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            Person = /** @class */ (function () {
                function Person(name, age, pan) {
                    this.Name = name;
                    this.Age = age;
                    this.Pan = pan;
                }
                Person.Lives = function () {
                    console.log("Person Lives for about 90years");
                };
                Person.prototype.GetFamilyMembers = function () {
                    console.log("Has parents, cousins and friends living together");
                };
                Person.prototype.Works = function () {
                    console.log("".concat(this.Name, " Works from home"));
                };
                return Person;
            }());
            exports_1("Person", Person);
        }
    };
});
System.register("Emp", ["PersonClass"], function (exports_2, context_2) {
    "use strict";
    var PersonClass_1, Employee;
    var __moduleName = context_2 && context_2.id;
    //JS class with overloading
    function jsEmployee() {
        this.Works = function () { return console.log('Works'); };
        this.Works = function (taskName) { return console.log("Works on ".concat(taskName)); };
    }
    exports_2("jsEmployee", jsEmployee);
    return {
        setters: [
            function (PersonClass_1_1) {
                PersonClass_1 = PersonClass_1_1;
            }
        ],
        execute: function () {
            Employee = /** @class */ (function (_super) {
                __extends(Employee, _super);
                function Employee(name, age, pan) {
                    return _super.call(this, name, age, pan) || this;
                }
                Employee.prototype.Works = function (taskName, status) {
                    var rest = [];
                    for (var _i = 2; _i < arguments.length; _i++) {
                        rest[_i - 2] = arguments[_i];
                    }
                    console.log("".concat(this.Name, " Works for Danske IT as ").concat(this.Designation, " on the task ").concat(taskName));
                };
                return Employee;
            }(PersonClass_1.Person));
            exports_2("Employee", Employee);
        }
    };
});
System.register("Main", ["PersonClass", "Emp"], function (exports_3, context_3) {
    "use strict";
    var PersonClass_2, Emp_1, Kalyan, Sanjeeb, Superperson;
    var __moduleName = context_3 && context_3.id;
    return {
        setters: [
            function (PersonClass_2_1) {
                PersonClass_2 = PersonClass_2_1;
            },
            function (Emp_1_1) {
                Emp_1 = Emp_1_1;
            }
        ],
        execute: function () {
            //// Create instances
            Kalyan = new PersonClass_2.Person("Kalyan");
            Kalyan.Works();
            Sanjeeb = new Emp_1.Employee('Sanjeeb', 29, 'AAOBH87721Z');
            Sanjeeb.Designation = "Senior Developer";
            Sanjeeb.Works('coding');
            //Base = new Derived()
            Superperson = new Emp_1.Employee('SuperPerson', 30, 'AGKUD392032Z');
            Superperson.Works();
            console.log("hello");
            document.getElementById('output').innerHTML = "Person Name: ".concat(Superperson.Name, ", Person Age: ").concat(Superperson.Age);
            // let jsEmpObj = new jsEmployee();
            // jsEmpObj.Works('typescript');
        }
    };
});
