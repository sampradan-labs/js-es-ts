System.register([], function (exports_1, context_1) {
    "use strict";
    var Person;
    var __moduleName = context_1 && context_1.id;
    return {
        setters: [],
        execute: function () {
            Person = /** @class */ (function () {
                function Person(name, age, pan) {
                    this.Name = name;
                    this.Age = age;
                    this.Pan = pan;
                }
                Person.Lives = function () {
                    console.log("Person Lives for about 90years");
                };
                Person.prototype.GetFamilyMembers = function () {
                    console.log("Has parents, cousins and friends living together");
                };
                Person.prototype.Works = function () {
                    console.log("".concat(this.Name, " Works from home"));
                };
                return Person;
            }());
            exports_1("Person", Person);
        }
    };
});
//# sourceMappingURL=PersonClass.js.map