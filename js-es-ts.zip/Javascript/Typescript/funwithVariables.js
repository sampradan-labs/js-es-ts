var str = "Good Day";
let num1 = 100.00;
let num2 = 300.00;
let arr = [true, true, false, true];
let obj = {
    id: "Total Cost",
    value: num1
};
console.log(`str=${str}, num1+num2=${num1 + num2}, arr:${arr}, obj:${obj} `);
function doSomething() {
    return 'Hands on with Typescript';
}
//calling doSomething()
console.log(doSomething());
var simplerWay = (msg) => console.log(`A new notification for you: ${msg}`);
var someMore = (msg, status) => { return `The message ${msg} is in ${status} state`; };
var tweak = function (arrows) {
    if (arrows == true)
        console.log("tweaking with arrow functions");
    else
        console.log("disabling arrow functions");
};
//Printing output of above 3
simplerWay("You have a new friend");
console.info(someMore("Important Email Notifications", true));
//A dynamic function type
let logicArray = ['console.log(a*b)', 'console.log(a+b)', 'console.log(a-b)', 'console.log(a/b)'];
var myFunnyFn = new Function('a', 'b', logicArray[0]);
myFunnyFn(25, 4);
/*
  function myFunnyFn(a,b){
      console.log(a*b);
  }
*/
//# sourceMappingURL=funwithVariables.js.map