//syntax class className<T>{} //T stands for any typescript type
//function fname<T>(p1,p2,...)
class  Bag<T>{
    private _list:T[] = [];
    public Add(item:T){
        this._list.push(item);
    }

    public Get():T[]{
        return this._list;
    }

    //Add the following
    public Update(item:T):boolean{}
    public Delete(item:T):boolean{}
}

//instantiate
let numBag = new Bag<number>();
numBag.Add(100);
numBag.Add(200);
numBag.Add(300);
numBag.Add(400);
numBag.Add(500);

console.log(numBag.Get());
/////
let objBag = new Bag<any>();
objBag.Add({id:1, item: 'Apparels'});
objBag.Add({id:2, item: 'Groceries'});
objBag.Add({id:3, item: 'Electronics'});
console.log(objBag.Get());

