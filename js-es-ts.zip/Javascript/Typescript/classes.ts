export const EMP_PREFIX = 'DANSKE-';
class Person{
    constructor(name?:string, age?:number, pan?:string){
        this.Name = name;
        this.Age = age;
        this.Pan = pan;
    }

    public Pan:string;
    public Name:string;
    public Age:number;
    protected TotalAssetsValue:number;
    private secrets:string[];
    static Lives():void{
        console.log(`Person Lives for about 90years`);
    }

    protected GetFamilyMembers(){
        console.log("Has parents, cousins and friends living together");
    }

    public Works():void{
        console.log(`${this.Name} Works from home`);
    }
}

class Employee extends Person{
    constructor(name:string, age:number, pan:string){
        super(name, age, pan);
    }

    public Designation:string;
    //overriding the behaviour
    public Works();
    public Works(taskname);
    public Works(taskName?:string, status?:boolean,...rest:string[]): void {
        console.log(`${this.Name} Works for Danske IT as ${this.Designation} on the task ${taskName}`);
    }    

}

//JS class with overloading
function jsEmployee(){
    this.Works = ()=>console.log('Works');
    this.Works = (taskName)=>console.log(`Works on ${taskName}`);
}


//// Create instances
let Kalyan:Person = new Person("Kalyan");
Kalyan.Works();

let Sanjeeb:Employee = new Employee('Sanjeeb', 29, 'AAOBH87721Z');
Sanjeeb.Designation = "Senior Developer"
Sanjeeb.Works('coding');

//Base = new Derived()
let Superperson: Person = new Employee('SuperPerson', 30, 'AGKUD392032Z');
Superperson.Works();

let jsEmpObj = new jsEmployee();
jsEmpObj.Works('typescript');
