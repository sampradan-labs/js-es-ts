abstract class Shape{
    abstract draw():void;
    public area():void{
        console.error('Area cannot be calculated without dimensions');
    }
}

class Circle extends Shape{
    public radius:number;
    draw(): void {
        console.log(`Circle drawn with radius ${this.radius}`);
    }

    public area(): void {
        console.log(`The area of circle is: ${Math.PI * this.radius * this.radius}`);
    }

}
let c = new Circle();
c.radius = 5;
c.draw();
c.area();