var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
function SelfDriving(constructorFn) {
    //constructorFn is called when the object of car is created
    console.log('--- Inside SelfDriving Decorator --');
    constructorFn.prototype.selfDrivable = true;
    constructorFn.prototype.gpsSystem = 'Google';
}
var Car = /** @class */ (function () {
    function Car(make) {
        console.log('-- this constructor invoked --');
        this._make = make;
    }
    Car = __decorate([
        SelfDriving
    ], Car);
    return Car;
}());
//--instantiate
var maruti = new Car("Maruti");
console.log(maruti);
console.log("selfdriving: ".concat(maruti['selfDrivable'], " \n            | GPS used: ").concat(maruti['gpsSystem']));
/// HTML using Typescript
//convert a class to a html tag
function HtmlComponent(constructorFn) {
    constructorFn.prototype.tag = '<user></user>';
    //document.appendChild(constructorFn.prototype.tag);
}
var User = /** @class */ (function () {
    function User() {
        console.log('User instantiated');
    }
    User = __decorate([
        HtmlComponent
    ], User);
    return User;
}());
//instantiate
var user = new User();
console.log("".concat(user['tag']));
