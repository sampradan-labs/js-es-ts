//syntax class className<T>{} //T stands for any typescript type
//function fname<T>(p1,p2,...)
var Bag = /** @class */ (function () {
    function Bag() {
        this._list = [];
    }
    Bag.prototype.Add = function (item) {
        this._list.push(item);
    };
    Bag.prototype.Get = function () {
        return this._list;
    };
    return Bag;
}());
//instantiate
var numBag = new Bag();
numBag.Add(100);
numBag.Add(200);
numBag.Add(300);
numBag.Add(400);
numBag.Add(500);
console.log(numBag.Get());
/////
var objBag = new Bag();
objBag.Add({ id: 1, item: 'Apparels' });
objBag.Add({ id: 2, item: 'Groceries' });
objBag.Add({ id: 3, item: 'Electronics' });
console.log(objBag.Get());
