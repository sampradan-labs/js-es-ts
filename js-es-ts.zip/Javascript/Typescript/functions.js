function increment(empName, defValue = 1, ctc = 1000000) {
    return `${empName} has received an upgraded ctc of INR ${Math.random() * defValue + ctc}`;
}
var execSP = (spName, ...params) => console.log(`Executing ${spName} with params ${params}`);
console.log(increment());
console.log(increment("Anand"));
console.log(increment("Anand", 10, 2000000));
execSP("spInsertEmployee", 1001, "Anand");
/*sequence of parameters combinetion
optional
default
*/
/*Write a function which has mandatory params, optional params, default params, rest params */
var fn = (defVal, ...r2) => {
    console.log(`defValue:${defVal}, r2: ${r2}`);
};
fn();
fn("Apples");
fn("Apples", "Oranges");
//===========
var Language;
//===========
(function (Language) {
    Language[Language["Typescript"] = 10] = "Typescript";
    Language[Language["CSharp"] = 20] = "CSharp";
    Language[Language["VB"] = 30] = "VB";
    Language[Language["Java"] = 40] = "Java";
    Language[Language["ES"] = 50] = "ES";
    Language[Language["JS"] = 60] = "JS";
})(Language || (Language = {}));
;
var getLanguage = () => Language.Typescript;
console.log(getLanguage());
//=========== TUPLES: Arrays that hold values of different datatypes
let mytuple = ["IPhone7", ['Gowns', 'Sarees', 'Formals'], 5000];
console.log(mytuple[0]);
console.log(mytuple[2]);
//===== UNION
let empId;
empId = 1001;
empId = 'DANSKE-' + 11874;
empId = 1;
function unite(val) {
    switch (val) {
        case 'value':
            return 5000;
            break;
        default:
            return 'Its as good as it gets';
            break;
    }
}
console.log(unite('value'));
console.log(unite(true));
//# sourceMappingURL=functions.js.map