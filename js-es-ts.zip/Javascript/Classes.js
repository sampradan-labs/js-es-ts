//Functions are first-class citizens

function NormalFunction(){
    console.log("Print...");
    return "Printing to Microsoft PDF printer";

}

function Movie(){

    //Creating properties in a public scope
    this.name='';
    this.cast=[];
    this.rating=0.0;
    this.ticketCost = 0.0;
    var privateProperty = 'I am private';

    //public functions
    this.Book = function(){return "Ticket booked for "+ this.name + '. Total cost is INR '+ this.ticketCost};
    var CanYouAccessMe = function(){
        return false;
    }
}


var Matrix = new Movie();   //Dynamically creating a JS Object

Matrix.name = "Matrix";
Matrix.cast = ['male lead role', 'supporting cast', 'director name', 'producer name'];
Matrix.rating = 4.2;
Matrix.ticketCost = 200.00;
console.log(Matrix);
console.log(Matrix.Book());

var movieCollection = [Matrix, new Movie()];
//changing the properties of the second item in the array
movieCollection[1].name = "Harry Potter";
movieCollection[1].cast = ['Daniel Radcliffe','Grint Rupert'];
movieCollection[1].Book();
movieCollection.push(new Movie());

//looping through
for (var index = 0; index < movieCollection.length; index++) {
    console.log(movieCollection[index].Book());    
}


//Using the prototype

Movie.prototype.OutProperty = "Defined outside the class";  //instance property
Movie.prototype.NewFunc = function(){ return "defined outside the class";}    //instance function
console.log(Movie.privateProperty);

var anotherMovie = new Movie();
console.log('Another Movie -----',anotherMovie);
console.log(anotherMovie.OutProperty);
console.log('Accessing NewFunc()-------', anotherMovie.NewFunc());